# IMDB-Movie-Reviews-Large-Dataset-50k
IMDB Movie Reviews Large Dataset - 50k Reviews

This dataset is taken from https://ai.stanford.edu/~amaas/data/sentiment/ and then preprocess to put all positive and negative reviews in the same file for training and testing. 
It help you to put more effort on algorithm instead of data collection.
